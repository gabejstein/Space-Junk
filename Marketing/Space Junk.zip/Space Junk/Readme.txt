Space Junk
----------
By Geibu3D

Itch Page: https://geibu3d.itch.io/

Twitter: @Geibu3d

E-mail: cheeseanimal86@gmail.com


Thank you for downloading "Space Junk". Be sure to check out my Itch page for more great products!


How to play
-----------
Your job is to clear space of garbage and debris. Try not to get hit.

Press the 'A' and 'D' keys to move the ship left and right.
Press 'Ctrl' to fire laser.

You get an extra life every 50 points.